# Quality of Life

The quality of life module that integrates with the core.

<!-- START DEFINITION TOC -->
# Table of Contents

- [Test](#test)
  - [Test](#test-1)
<!-- END DEFINITION TOC -->


## Test

### Test


 [05:11] [PrephsFramework][TRACE]: Getting or creating run data for current instance... 
 [05:11] [PrephsFramework][TRACE]: Looking for existing run with ID 'Sess-Prephmage-0318' among 1 runs 
 [05:11] [PrephsFramework][TRACE]: Run already found for ID 'Sess-Prephmage-0318' 
 [05:11] Changed Channel: [2. General - Dun Morogh] 
 [05:11] Left Channel: [3. Trade - City] 
 [05:13] [PrephsFramework][TRACE]: Getting or creating run data for current instance... 
 [05:13] [PrephsFramework][TRACE]: Looking for existing run with ID 'Sess-Prephmage-0318' among 1 runs 
 [05:13] [PrephsFramework][TRACE]: Run already found for ID 'Sess-Prephmage-0318' 
 [05:13] Changed Channel: [2. General - Gnomeregan] 
 [05:16] Welcome to Gnomeregan. This raid instance is scheduled to reset in 0d 23h 42m. 
 [05:16] [PrephsFramework][TRACE]: Getting or creating run data for current instance... 
 [05:16] [PrephsFramework][TRACE]: Looking for existing run with ID 'Sess-Prephmage-0318' among 0 runs 
 [05:16] [PrephsFramework][TRACE]: Run not found for ID 'Sess-Prephmage-0318'