# PrephsFramework Core 

The core module.

<!-- START DEFINITION TOC -->

<!-- END DEFINITION TOC -->