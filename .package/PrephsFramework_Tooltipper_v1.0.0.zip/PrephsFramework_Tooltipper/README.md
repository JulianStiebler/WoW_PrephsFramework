A tooltipper addon with cross-account functionality with main-focus on SoD, with some extra functionality that once existed in similar addons.

Depends on my [Core Framework](https://www.curseforge.com/wow/addons/prephsframeworkcore)

<!-- START DEFINITION TOC -->
# Table of Contents

- [What it offers](#what-it-offers)
- [Planned Features](#planned-features)
- [Known bugs planned fixing](#known-bugs-planned-fixing)
<!-- END DEFINITION TOC -->

## What it offers

*   Cross Account Synchronization capabilites via smart ingame addonmessage management
*   Cross Faction Indications and toggles
*   Character Overview showing
    *   Weekly Lockouts
    *   toggleable Weekly and Daily Quests
    *   Main and secondary professions
    *   Has a note field
*   Typical item count across items, including mail and auction house counts (it cannot detect auctions being sold due to API limitations, be wary on AH count)
*   Ability to extend normal tooltips with things like
    *   For Items
        *   ItemID
        *   VendorPrice
        *   SpellID (if avaiable)
        *   IconID
    *   For Buff/Debuffs
        *   SpellID
        *   SourceName ( if avaiable)
        *   SourceID (if avaiable)
        *   IconID
    *   For Items
        *   SpellID
        *   AuraID (if avaiable)
        *   IconID

## Planned Features

*   none yet

## Known bugs planned fixing

*   none yet