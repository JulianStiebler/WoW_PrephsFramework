# Quality of Life

The quality of life module that integrates with the core.

<!-- START DEFINITION TOC -->
# Table of Contents

<!-- END DEFINITION TOC -->
